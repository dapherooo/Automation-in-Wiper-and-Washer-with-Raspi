import cv2
import numpy as np
import RPi.GPIO as GPIO
from time import sleep

x_medium = 0


class Motor():
    def __init__(self, in1, in2):
        self.in1 = in1
        self.in2 = in2
        GPIO.setmode(GPIO.BCM)
        GPIO.setwarnings(False)
        GPIO.setup(self.in1, GPIO.OUT)
        GPIO.setup(self.in2, GPIO.OUT)


    def turun(self, x=50, t=0):
        self.p = GPIO.PWM(self.in1, 1000)  # Frequency in Hz
        self.p.start(0)  # DutyCycle
        GPIO.output(self.in2, GPIO.LOW)
        self.p.ChangeDutyCycle(x)
        # print('MOVE TO RIGHT')
        sleep(t)

    def naik(self, x=50, t=0):
        self.p = GPIO.PWM(self.in2, 1000)  # Frequency in Hz
        self.p.start(0)  # DutyCycle
        GPIO.output(self.in1, GPIO.LOW)
        self.p.ChangeDutyCycle(x)
        # print('MOVE TO LEFT')
        sleep(t)

    def stop(self):
        GPIO.output(self.in1, GPIO.LOW)
        GPIO.output(self.in2, GPIO.LOW)
        self.p.ChangeDutyCycle(0)
        # print('NOT MOVING')


def nothing(x):
    pass


motor1 = Motor(16, 12) # D0 D1
motor2 = Motor(20, 21) # D2 D3

cam = cv2.VideoCapture(1)
cv2.namedWindow("Trackbars")

#Create Trackbar from library opencv range 0-255 (minimum and maximum RGB color)
cv2.createTrackbar("L-H", "Trackbars", 0, 255, nothing)
cv2.createTrackbar("L-S", "Trackbars", 0, 255, nothing)
cv2.createTrackbar("L-V", "Trackbars", 0, 255, nothing)
cv2.createTrackbar("U-H", "Trackbars", 0, 255, nothing)
cv2.createTrackbar("U-S", "Trackbars", 0, 255, nothing)
cv2.createTrackbar("U-V", "Trackbars", 0, 255, nothing)

while True:
    ret, frame = cam.read()
    frame = cv2.flip(frame, 1)
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # #Get Trackbar Position from library opencv
    # l_h = cv2.getTrackbarPos("L-H", "Trackbars")
    # l_s = cv2.getTrackbarPos("L-S", "Trackbars")
    # l_v = cv2.getTrackbarPos("L-V", "Trackbars")
    # u_h = cv2.getTrackbarPos("U-H", "Trackbars")
    # u_s = cv2.getTrackbarPos("U-S", "Trackbars")
    # u_v = cv2.getTrackbarPos("U-V", "Trackbars")

    # RGB Sample Color 1 (Green)
    color1 = np.array([39, 44, 38])
    color2 = np.array([81, 83, 94 ])
    color_mask1 = cv2.inRange(rgb_frame, color1, color2)

    # RGB Sample Color 2 (Brown)
    color3 = np.array([135, 114, 57])
    color4 = np.array([161, 148, 110])
    color_mask2 = cv2.inRange(rgb_frame, color3, color4)

    # RGB Sampel Color 3(Red)
    color5 = np.array([142, 62, 23])
    color6 = np.array([212, 80, 67])
    color_mask3 = cv2.inRange(rgb_frame, color5, color6)

    #RGB Trackbar for detecting Contour with RGB Range
    # color1 = np.array([l_h, l_s, l_v])
    # color2 = np.array([u_h, u_s, u_v])
    # color_mask1 = cv2.inRange(rgb_frame, color1, color2)

    # Color Contour for 1 Color
    # color_mask = color_mask1

    # Color Contour for 2 Colors
    # color_mask = color_mask2 + color_mask3

    # Color Contour for 3 Colors
    color_mask = color_mask1 + color_mask2 + color_mask3
    contours, _ = cv2.findContours(color_mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    contours = sorted(contours, key=lambda x:cv2.contourArea(x), reverse=True)

    for cnt in contours:
        (x, y, w, h) = cv2.boundingRect(cnt)
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
        break

    cv2.imshow('Frame', frame)
    cv2.imshow('Mask', color_mask)

    key = cv2.waitKey(1)
    if key == 27:
        break


    # motor movement
    if x_medium > 0:
        motor1.turun(50, 1)
        motor1.naik(50, 1)
        # motor2.right(90, 2)

    else:
        motor1.stop()
        # motor2.stop()

GPIO.cleanup()
cam.release()
cv2.destroyAllWindows()

